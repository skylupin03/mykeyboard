# The ISO variant of the Keychron Q1

- Add EC11 rotary encoder support.
- Turn colckwise to increase volume and turn anti-colckwise to decrease volume.
- Press the encoder key to mute.
