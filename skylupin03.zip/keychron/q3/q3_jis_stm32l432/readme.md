# The JIS variant of the Keychron Q3
