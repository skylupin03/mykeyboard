# The ISO variant of the Keychron Q3

- Enable EC11 rotary encoder.
- Turn colckwise to increase volume and turn anti-colckwise to decrease volume.
- Press top right key pushbutton to mute.
