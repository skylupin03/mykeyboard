# The ANSI variant of the Keychron Q3

- Enable rotary encoder support.
- Turn colckwise to increase volume and turn anti-colckwise to decrease volume.
- Press top right key pushbutton to mute.
