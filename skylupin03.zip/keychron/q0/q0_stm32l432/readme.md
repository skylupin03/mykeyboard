# The base variant of the Keychron Q0
